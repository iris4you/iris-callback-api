<?php

define('UB_ERROR_NO_DATA', 1);
define('UB_ERROR_NO_METHOD_FOUND', 2);
define('UB_ERROR_USER_SECRET', 3);
define('UB_ERROR_NO_CHAT', 4);
define('UB_ERROR_CANT_BIND_CHAT', 10);