<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'admin');
define('DB_PASSWORD', 'password');
define('DB_DATABASE', 'ub_database');